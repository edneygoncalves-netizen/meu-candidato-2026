# Consulta Candidatos 2026 — versão 3

Aplicação mobile-first que consulta candidatos de 2026 usando o endpoint do DivulgaCandContas do TSE através de um intermediário `/api/search`.

## Estrutura

- `index.html` — interface
- `api/search.js` — função servidor que consulta o TSE
- `vercel.json` — configuração de deploy

## Deploy

1. Crie uma conta em Vercel.
2. Crie um novo projeto e envie estes arquivos para um repositório GitHub, ou importe o projeto.
3. Faça o deploy.
4. A URL gerada pela Vercel será o endereço público do site.

Não é necessário colocar chave de API.

## Observações

- A fonte de dados é o TSE/DivulgaCandContas.
- O projeto usa o identificador da eleição de 2026: `20322002026`.
- O backend aplica cache curto para reduzir chamadas repetidas ao TSE.
- A versão atual consulta um estado por vez; a opção Brasil é direcionada à Presidência.
- Para uma busca nacional de Senado/deputados, a próxima evolução é indexar o conjunto CSV oficial do TSE no servidor, em vez de fazer dezenas de consultas ao vivo.
